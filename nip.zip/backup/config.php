<?php

if (!defined("__IN_NIP__")) {
    exit();
}

define("HOST", "saekip.mysql.tools");

define("USERNAME", "saekip_pip");

define("PASSWORD", "94SYDiBbt3j6");

define("DATABASE", "saekip_pip");

?>